
m = matrix(c(40,33,3,12),ncol = 2,byrow = TRUE)
m
rownames(m) = c('Drinks tea','Does not drink tea')

colnames(m) = c('Smoker','Non-smoker')
m

#calculate Yule's Q

Q = (m[1,1]*m[2,2] - m[1,2]*m[2,1]) / (m[1,1]*m[2,2] + m[1,2]*m[2,1])
Q
cat("Yule's Q value is :",Q,"\n")


#Question 1


# Control group data
control <- c(1042, 1617, 1180, 973, 1552, 1251, 1151, 1511, 728, 1079, 951, 1319)

# Test group data
test <- c(874, 389, 612, 798, 1152, 893, 541, 741, 1064, 862, 213)

# Perform Mann-Whitney U test
mann_whitney <- wilcox.test(control, test)

# Print the results
print(mann_whitney)

